#!/system/bin/sh
# Ensures Kernel Loader recognizes signature-unlocked status on every boot
mkdir -p /data/adb/kernel_loader 2>/dev/null
echo "sig_unlocked=true" > /data/adb/kernel_loader/status.prop 2>/dev/null
