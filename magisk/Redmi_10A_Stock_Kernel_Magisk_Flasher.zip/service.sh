#!/system/bin/sh
mkdir -p /data/adb/kernel_loader 2>/dev/null
echo "stock_kernel_fixed=true" > /data/adb/kernel_loader/status.prop 2>/dev/null
