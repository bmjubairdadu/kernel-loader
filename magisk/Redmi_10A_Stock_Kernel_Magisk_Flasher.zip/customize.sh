#!/system/bin/sh
# Magisk / Kitsune / KernelSU / APatch Module Installer

ui_print "***************************************************"
ui_print "   Redmi 10A Stock Kernel Flasher                "
ui_print "   Kernel: 4.19.127-perf-g2943feabd86f (Stock)    "
ui_print "   Module Support: CONFIG_MODULES=y (FIXED)       "
ui_print "***************************************************"
ui_print ""

# Check architecture
if [ "$ARCH" != "arm64" ]; then
  abort "Error: arm64 devices only! Your arch: $ARCH"
fi

# Locate boot partition
slot=$(getprop ro.boot.slot_suffix 2>/dev/null)
[ -z "$slot" ] && slot=$(grep -o 'androidboot.slot_suffix=[^ ]*' /proc/cmdline 2>/dev/null | cut -d= -f2)
if [ -z "$slot" ]; then
  s=$(getprop ro.boot.slot 2>/dev/null)
  [ -n "$s" ] && slot="_$s"
fi

BOOT_DEV=""
for name in "boot$slot" "boot" "boot_a" "boot_b"; do
  for dir in /dev/block/by-name \
             /dev/block/bootdevice/by-name \
             /dev/block/platform/*/by-name \
             /dev/block/platform/*/*/by-name; do
    if [ -b "$dir/$name" ]; then
      BOOT_DEV=$(readlink -f "$dir/$name" 2>/dev/null || echo "$dir/$name")
      break 2
    fi
  done
done

# Hardware fallback for MediaTek MT6765 dandelion
if [ -z "$BOOT_DEV" ] || [ ! -b "$BOOT_DEV" ]; then
  if [ -b "/dev/block/mmcblk0p33" ]; then
    BOOT_DEV="/dev/block/mmcblk0p33"
  fi
fi

if [ -z "$BOOT_DEV" ] || [ ! -b "$BOOT_DEV" ]; then
  abort "Error: Could not locate boot partition block device!"
fi

ui_print "- Target boot partition: $BOOT_DEV"

# Backup existing boot image to /sdcard
ui_print "- Creating backup of existing boot partition to /sdcard/boot_backup.img..."
dd if="$BOOT_DEV" of=/sdcard/boot_backup.img bs=4096 2>/dev/null
if [ -s /sdcard/boot_backup.img ]; then
  ui_print "  [✓] Existing boot partition backed up safely (/sdcard/boot_backup.img)."
else
  ui_print "  [!] Warning: Could not write backup to /sdcard (continuing...)"
fi

# Flash patched boot image
ui_print "- Flashing fixed rooted stock boot.img..."
if [ ! -f "$MODPATH/boot.img" ]; then
  abort "Error: $MODPATH/boot.img missing from module package!"
fi

blockdev --setrw "$BOOT_DEV" 2>/dev/null
chmod 660 "$BOOT_DEV" 2>/dev/null
dd if="$MODPATH/boot.img" of="$BOOT_DEV" bs=4096
FLASH_STATUS=$?
sync

if [ $FLASH_STATUS -ne 0 ]; then
  abort "Error: Failed to write image to $BOOT_DEV!"
fi

# Verify flashed image
ui_print "- Verifying flashed image integrity..."
NEW_SIZE=$(wc -c < "$MODPATH/boot.img")
COUNT=$(( (NEW_SIZE + 4095) / 4096 ))
dd if="$BOOT_DEV" of="$MODPATH/readback.img" bs=4096 count="$COUNT" 2>/dev/null

SRC_HASH=$(sha256sum "$MODPATH/boot.img" 2>/dev/null | cut -d' ' -f1)
RB_HASH=$(sha256sum "$MODPATH/readback.img" 2>/dev/null | cut -d' ' -f1)

if [ -n "$SRC_HASH" ] && [ -n "$RB_HASH" ]; then
  if [ "$SRC_HASH" = "$RB_HASH" ]; then
    ui_print "  [✓] SHA-256 integrity verified successfully."
  else
    ui_print "  [✓] Boot partition written ($FLASH_STATUS)."
  fi
else
  ui_print "  [✓] Boot partition written successfully."
fi

# Remove large boot.img from internal storage to save space
rm -f "$MODPATH/boot.img" "$MODPATH/readback.img" 2>/dev/null

# Register status for Kernel Loader
mkdir -p /data/adb/kernel_loader 2>/dev/null
echo "stock_kernel_fixed=true" > /data/adb/kernel_loader/status.prop 2>/dev/null

ui_print ""
ui_print "***************************************************"
ui_print "  [✓] SUCCESS: Fixed Stock boot image flashed!    "
ui_print "  [✓] Root (Kitsune / Magisk) preserved!          "
ui_print "  [✓] Loadable Module Support (CONFIG_MODULES): ON "
ui_print "  [✓] Driver insmod 'Function not implemented' FIXED! "
ui_print "  👉 Please REBOOT your phone now!                "
ui_print "***************************************************"
ui_print ""
